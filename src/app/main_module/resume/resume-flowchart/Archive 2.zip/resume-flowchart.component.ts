import * as d3 from 'd3';

import { AfterViewInit, Component, ElementRef, OnChanges, SimpleChanges, ViewChild } from '@angular/core';
import { Location, PlatformLocation } from '@angular/common';

import { NgZone } from '@angular/core';

@Component({
  selector: 'app-resume-flowchart',
  standalone: true,
  templateUrl: './resume-flowchart.component.html',
  styleUrls: ['./resume-flowchart.component.scss']
})
export class ResumeFlowchartComponent implements AfterViewInit, OnChanges {
  svg: any;
  node: any;
  @ViewChild('treeContainer', { static: false }) private chartContainer: ElementRef | undefined;
  @ViewChild('flowChartContainer', { static: false }) flowChartContainer!: ElementRef;

  private rootData: any;

  constructor(private platformLocation: PlatformLocation, private location: Location, private ngZone: NgZone) { }

  ngOnInit(): void {
  }

  ngOnChanges(changes: SimpleChanges): void {
  }

  ngAfterViewInit() {
    this.testFunction();
  }

  rootDataList = {
    "name": "flare",
    "children": [{
      "name": "analytics",
      "children": [{
        "name": "cluster",
        "children": [{
          "name": "AgglomerativeCluster",
          "size": 3938
        }, {
          "name": "CommunityStructure",
          "size": 3812
        }, {
          "name": "HierarchicalCluster",
          "size": 6714
        }, {
          "name": "MergeEdge",
          "size": 743
        }]
      }, {
        "name": "graph",
        "children": [{
          "name": "BetweennessCentrality",
          "size": 3534
        }, {
          "name": "LinkDistance",
          "size": 5731
        }, {
          "name": "MaxFlowMinCut",
          "size": 7840
        }, {
          "name": "ShortestPaths",
          "size": 5914
        }, {
          "name": "SpanningTree",
          "size": 3416
        }]
      }, {
        "name": "optimization",
        "children": [{
          "name": "AspectRatioBanker",
          "size": 7074
        }]
      }]
    }
    ]
  };
  i: any = 0;
  duration: any = 750;
  rectW: any = 60;
  rectH: any = 30;

  margin: any = { top: 20, right: 120, bottom: 20, left: 120 };
  width: any = 960 - this.margin.right - this.margin.left;
  height: any = 800 - this.margin.top - this.margin.bottom;

  diagonal = d3.linkVertical()
    .x((d: any) => d.y + this.rectH / 2)
    .y((d: any) => d.x + this.rectW / 2);
  zoomBehavior: any = d3.zoom()
    .scaleExtent([1, 3])
    .on("zoom", (event) => this.redraw(event));
  root3: any = d3.hierarchy(this.rootDataList);
  treeLayout: any = d3.tree().nodeSize([70, 40]);

  testFunction() {
    if (this.flowChartContainer?.nativeElement) {
      const container = this.flowChartContainer.nativeElement;

      if (!container.querySelector('svg')) {
        const svgSelection = d3.select(container)
          .append("svg")
          .attr("width", 1000)
          .attr("height", 1000)
          .call(this.zoomBehavior);

        this.svg = svgSelection.append("g")
          .attr("transform", "translate(350,20)");

        // ✅ Delay transform safely using NgZone and setTimeout
        this.ngZone.runOutsideAngular(() => {
          setTimeout(() => {
            const initialTransform = d3.zoomIdentity.translate(350, 20);
            svgSelection.call(this.zoomBehavior.transform, initialTransform);
          }, 0);
        });

        // Ensure root is defined and has children before accessing
        if (this.rootDataList && Array.isArray(this.rootDataList.children)) {
          this.root3.x0 = 0;
          this.root3.y0 = this.height / 2;

          this.rootDataList.children.forEach((child: any) => this.collapse(child));
        } else {
          console.error('Root or children not defined or invalid.');
        }
        this.treeLayout(this.root3);
        this.update(this.root3);
      }
    }
  }

  update(source: any) {

    this.treeLayout(this.root3); // Lays out the tree (mutates root3)

    let nodes = this.root3.descendants().reverse();
    let links = this.root3.links();

    // Normalize for fixed-depth.
    nodes.forEach(function (d: any) {
      d.y = d.depth * 180;
    });

    // Update the nodes…
    let node = this.svg.selectAll("g.node")
      .data(nodes, function (d: any, i: any) {
        return d.id || (d.id = ++i);
      });

    // Enter any new nodes at the parent's previous position.
    let nodeEnter = node.enter().append("g")
      .attr("class", "node")
      .attr("transform", function (d: any) {
        return "translate(" + source.x0 + "," + source.y0 + ")";
      })
      .on("click", (event: any, d: any) => this.click(event, d));

    // .on("click", this.click);

    nodeEnter.append("rect")
      .attr("width", this.rectW)
      .attr("height", this.rectH)
      .attr("stroke", "black")
      .attr("stroke-width", 1)
      .style("fill", function (d: any) {
        return d._children ? "lightsteelblue" : "#fff";
      });

    nodeEnter.append("text")
      .attr("x", this.rectW / 2)
      .attr("y", this.rectH / 2)
      .attr("dy", ".35em")
      .attr("text-anchor", "middle")
      .text(function (d: any) {
        return d.name;
      });

    // Transition nodes to their new position.
    let nodeUpdate = node.transition()
      .duration(this.duration)
      .attr("transform", function (d: any) {
        return "translate(" + d.x + "," + d.y + ")";
      });

    nodeUpdate.select("rect")
      .attr("width", this.rectW)
      .attr("height", this.rectH)
      .attr("stroke", "black")
      .attr("stroke-width", 1)
      .style("fill", function (d: any) {
        return d._children ? "lightsteelblue" : "#fff";
      });

    nodeUpdate.select("text")
      .style("fill-opacity", 1);

    // Transition exiting nodes to the parent's new position.
    let nodeExit = node.exit().transition()
      .duration(this.duration)
      .attr("transform", function (d: any) {
        return "translate(" + source.x + "," + source.y + ")";
      })
      .remove();

    nodeExit.select("rect")
      .attr("width", this.rectW)
      .attr("height", this.rectH)
      //.attr("width", bbox.getBBox().width)""
      //.attr("height", bbox.getBBox().height)
      .attr("stroke", "black")
      .attr("stroke-width", 1);

    nodeExit.select("text");

    // Update the links…
    let link = this.svg.selectAll("path.link")
      .data(links, function (d: any) {
        return d.target.id;
      });

    this.diagonal = d3.linkHorizontal()
      .x((d: any) => d.y)
      .y((d: any) => d.x);

    // Enter any new links at the parent's previous position.
    link.enter().insert("path", "g")
      .attr("class", "link")
      .attr("x", this.rectW / 2)
      .attr("y", this.rectH / 2)
      .attr("d", (d: any) => this.diagonal(d));

    // Transition links to their new position.
    link.transition()
      .duration(this.duration)
      .attr("d", this.diagonal);

    // Transition exiting nodes to the parent's new position.
    link.exit().transition()
      .duration(this.duration)
      .attr("d", (d: any) => this.diagonal(d))// d = { source, target } with x/y
      .remove();

    // Stash the old positions for transition.
    nodes.forEach(function (d: any) {
      d.x0 = d.x;
      d.y0 = d.y;
    });
  }



  click(event: any, d: any) {
    if (d.children) {
      d._children = d.children;
      d.children = null;
    } else {
      d.children = d._children;
      d._children = null;
    }
    this.update(d);
  }


  collapse(d: any) {
    if (d.children) {
      d._children = d.children;
      d.children.forEach((child: any) => this.collapse(child));
      d.children = null;
    }
  }

  redraw(event: any) {
    this.svg.attr("transform", event.transform);
  }



}


